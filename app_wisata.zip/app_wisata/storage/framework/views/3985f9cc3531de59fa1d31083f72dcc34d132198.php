<?php $__env->startSection('content'); ?>
<h2><?php echo e($wisatas->nama); ?></h2>
<th>Lokasi : <?php echo e($wisatas->kota); ?></th><br>
<th>Harga Tiket : <?php echo e($wisatas->harga_tiket); ?></th><br>
<th>Desktripsi : <?php echo e($wisatas->deskripsi); ?></th><br>
<th><img src="<?php echo e(Storage::url('public/images/'). $wisatas->image); ?>" class="rounded" style="width: 150px"></td></th><br><br>
<a class="form-control btn btn-warning" href="<?php echo e(route('wisata.index')); ?>">Home</a><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisata.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app_wisata/resources/views/wisata/show.blade.php ENDPATH**/ ?>