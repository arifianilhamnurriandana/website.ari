<?php $__env->startSection('content'); ?>
<a class="btn btn-primary float-end" href="<?php echo e(route('wisatas.create')); ?>">Add New</a><br><br>
<div class="row">
<?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-sm-3">
        <div class="card">
            <div class="card-body">
                <img src="<?php echo e(Storage::url('public/images/'). $a->image); ?>" class="card-img-top" alt="...">
                <h2><?php echo e($a->nama); ?></h2>
                <th>Kota : <?php echo e($a->kota); ?></th><br>
                <th>Harga Tiket : <?php echo e($a->harga_tiket); ?></th><br>
                <br><a class="btn btn-success" href="<?php echo e(route('wisatas.edit', $a->id)); ?>">Edit</a>
                <a class="btn btn-warning" href="<?php echo e(route('wisatas.show', $a->id)); ?>">Show</a>
                <form action="<?php echo e(route('wisatas.destroy', $a->id)); ?>" method="post" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app_wisata/resources/views/wisatas/index.blade.php ENDPATH**/ ?>