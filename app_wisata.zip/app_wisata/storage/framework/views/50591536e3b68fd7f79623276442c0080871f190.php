<?php $__env->startSection('content'); ?>
<th><img src="<?php echo e(Storage::url('public/images/'). $wisatas->image); ?>" class="rounded" style="width: 500px"></td></th><br><br>
<h1><?php echo e($wisatas->nama); ?></h1>
<th>Lokasi : <?php echo e($wisatas->kota); ?></th><br>
<th>Harga Tiket : <?php echo e($wisatas->harga_tiket); ?></th><br>
<th>Deskripsi</th><br>
<?php echo e($wisatas->deskripsi); ?>

<a class="form-control btn btn-warning" href="<?php echo e(route('wisatas.index')); ?>">Home</a><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app_wisata/resources/views/wisatas/show.blade.php ENDPATH**/ ?>